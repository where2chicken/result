import React from "react";

const tableData = [
  { 상권: "오목교역", 매출: 1535365127, 점포수: 3, 유사업종수: 11 },
  { 상권: "종로·청계 관광특구", 매출: 1336880320, 점포수: 18, 유사업종수: 28 },
  { 상권: "역삼역", 매출: 1336831120, 점포수: 11, 유사업종수: 23 },
  { 상권: "종각역", 매출: 1273509922, 점포수: 9, 유사업종수: 19 },
  { 상권: "강남역", 매출: 992535406, 점포수: 8, 유사업종수: 18 },
];

const TableView = () => {
  return (
    <div>
      <h2
        style={{ fontSize: "20px", fontWeight: "bold", marginBottom: "16px" }}>
        치킨 상권 매출 TOP 30
      </h2>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ background: "#f9f9f9" }}>
            <th style={{ padding: "8px", borderBottom: "1px solid #ddd" }}>
              상권
            </th>
            <th style={{ padding: "8px", borderBottom: "1px solid #ddd" }}>
              매출
            </th>
            <th style={{ padding: "8px", borderBottom: "1px solid #ddd" }}>
              점포 수
            </th>
            <th style={{ padding: "8px", borderBottom: "1px solid #ddd" }}>
              유사 업종 수
            </th>
          </tr>
        </thead>
        <tbody>
          {tableData.map((row, idx) => (
            <tr key={idx}>
              <td style={{ padding: "8px", borderBottom: "1px solid #eee" }}>
                {row.상권}
              </td>
              <td style={{ padding: "8px", borderBottom: "1px solid #eee" }}>
                {row.매출.toLocaleString()} 원
              </td>
              <td style={{ padding: "8px", borderBottom: "1px solid #eee" }}>
                {row.점포수}
              </td>
              <td style={{ padding: "8px", borderBottom: "1px solid #eee" }}>
                {row.유사업종수}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TableView;
