/** @jsxImportSource @emotion/react */
import React, { useState } from "react";
import styled from "@emotion/styled";

interface FilterProps {
  onFilterChange: (filters: Filters) => void;
}

export interface Filters {
  minStores: number;
  maxStores: number;
  minSales: number;
  maxSales: number;
}

const defaultFilters: Filters = {
  minStores: 0,
  maxStores: 100,
  minSales: 0,
  maxSales: 1000000000,
};

const MapFilterControls: React.FC<FilterProps> = ({ onFilterChange }) => {
  const [filters, setFilters] = useState<Filters>(defaultFilters);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    key: keyof Filters
  ) => {
    const value = Number(e.target.value);
    const updated = { ...filters, [key]: value };
    setFilters(updated);
    onFilterChange(updated);
  };

  return (
    <FilterWrapper>
      <label>
        점포수 최소
        <input
          type="number"
          value={filters.minStores}
          onChange={(e) => handleChange(e, "minStores")}
        />
      </label>
      <label>
        점포수 최대
        <input
          type="number"
          value={filters.maxStores}
          onChange={(e) => handleChange(e, "maxStores")}
        />
      </label>
      <label>
        매출액 최소
        <input
          type="number"
          value={filters.minSales}
          onChange={(e) => handleChange(e, "minSales")}
        />
      </label>
      <label>
        매출액 최대
        <input
          type="number"
          value={filters.maxSales}
          onChange={(e) => handleChange(e, "maxSales")}
        />
      </label>
    </FilterWrapper>
  );
};

export default MapFilterControls;

const FilterWrapper = styled.div`
  display: flex;
  gap: 12px;
  justify-content: center;
  margin: 20px auto;
  max-width: 800px;
  flex-wrap: wrap;
  padding: 16px;
  border: 1px solid #eee;
  border-radius: 12px;
  background: #fffde7;

  label {
    display: flex;
    flex-direction: column;
    font-size: 14px;
    color: #444;

    input {
      margin-top: 4px;
      padding: 6px 8px;
      border: 1px solid #ccc;
      border-radius: 6px;
      width: 120px;
    }
  }
`;
