/** @jsxImportSource @emotion/react */
import React, { useState, useRef, useEffect } from "react";
import styled from "@emotion/styled";

const qaPairs = [
  {
    question: "서울에서 가장 매출이 잘 나오는 치킨집 위치의 특징이 뭐야?",
    answer: [
      "치킨 전문점 점포 수가 많은 상권 (예: 명동 관광특구, 잠실 관광특구 등)",
      "20–30대 인구가 많음",
      "총 가구 수가 많음 (특히 비아파트 비율이 높을수록 젊은 유동 인구일 가능성)",
      "개업율이 적당히 존재",
      "유사업종 경쟁 비율이 지나치게 높지 않음",
    ],
  },
  {
    question: "직장인 많은 지역이랑 주거지역 중 어디가 치킨집에 더 유리해?",
    answer: [
      "👉 주거형 상권이 더 유리해요!",
      "저녁 시간대 배달 중심 소비가 활발하고, 20~40대 상주 인구 밀집 지역에서 반복 주문이 많습니다.",
      "최근 회식 수요는 줄고, 가정 내 배달 수요는 증가하고 있기 때문이에요.",
    ],
  },
  {
    question: "경쟁 치킨집이 적은 지역을 추천해줘.",
    answer: [
      "✔ 경쟁 치킨집이 적은 지역의 특징:",
      "- 치킨 전문점 점포 수는 최소 3개 이상",
      "- 유사업종 점포 수가 적고",
      "- 2030 상주 인구가 적절히 존재",
      "- 개업율이 0이 아님",
      "",
      "🔍 추천 지역:",
      "- 배화여자대학교 인근 (서대문구)",
      "- 신촌 이화여대 부근",
    ],
  },
  {
    question: "주말 매출이 특히 높은 지역은 어디야?",
    answer: [
      "📈 주말 매출이 높은 대표 상권:",
      "1. 망원시장 — 주중: 70,478,573원 / 주말: 81,313,030원 / 차이: 10,834,457원",
      "2. 금남시장 — 주중: 41,719,816원 / 주말: 51,372,280원 / 차이: 9,652,466원",
      "3. 도곡초등학교 — 주중: 1,204,514원 / 주말: 3,412,788원 / 차이: 2,208,274원",
      "4. 홍제역 2번 출구 — 주중: 977,565원 / 주말: 1,195,041원 / 차이: 217,476원",
    ],
  },
  {
    question: "치킨집 평균 매출이 높은 지역 알려줘!",
    answer: [
      "💰 평균 매출 상위 지역 (상위 10개 중 일부):",
      "1. 명동 남대문 북창동 무교동 관광특구 — 평균 매출 약 118,000,000원",
      "2. 잠실역 인근 — 평균 매출 약 102,000,000원",
      "3. 신림역 근처 대학가 — 평균 매출 약 95,000,000원",
      "4. 홍대입구역 — 평균 매출 약 92,000,000원",
      "5. 신촌역 상권 — 평균 매출 약 89,000,000원",
    ],
  },
];

const ChatAssistant = () => {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<
    { type: "user" | "bot"; text: string }[]
  >([]);
  const chatRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatRef.current) {
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    }
  }, [messages]);

  const handleQuestion = (text: string, answerLines: string[]) => {
    setMessages((prev) => [
      ...prev,
      { type: "user", text },
      { type: "bot", text: "..." },
    ]);

    setTimeout(() => {
      const answers = answerLines.map((line) => ({
        type: "bot" as const,
        text: line,
      }));
      setMessages((prev) => [...prev.slice(0, -1), ...answers]);
    }, 1000);
  };

  return (
    <>
      <FloatingButton onClick={() => setOpen(!open)}>💬</FloatingButton>

      {open && (
        <ChatWindow>
          <Header>도움이 필요하신가요?</Header>
          <ChatLog ref={chatRef}>
            {messages.map((msg, idx) => (
              <ChatBubble key={idx} type={msg.type}>
                {msg.text}
              </ChatBubble>
            ))}
          </ChatLog>
          <ButtonGroup>
            {qaPairs.map((q, idx) => (
              <ChatButton
                key={idx}
                onClick={() => handleQuestion(q.question, q.answer)}>
                {q.question}
              </ChatButton>
            ))}
          </ButtonGroup>
        </ChatWindow>
      )}
    </>
  );
};

export default ChatAssistant;

const FloatingButton = styled.button`
  position: fixed;
  bottom: 80px;
  right: 40px;
  background: #ffb300;
  border: none;
  border-radius: 50%;
  width: 60px;
  height: 60px;
  font-size: 26px;
  color: white;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  cursor: pointer;
  z-index: 1000;
`;

const ChatWindow = styled.div`
  position: fixed;
  bottom: 100px;
  right: 24px;
  width: 320px;
  background: white;
  border-radius: 12px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
  overflow: hidden;
  z-index: 999;
  display: flex;
  flex-direction: column;
`;

const Header = styled.div`
  background: #ffb300;
  color: white;
  font-weight: bold;
  padding: 12px;
  text-align: center;
`;

const ChatLog = styled.div`
  max-height: 260px;
  overflow-y: auto;
  padding: 12px;
  font-size: 14px;
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  gap: 8px;
`;

const ChatBubble = styled.div<{ type: "user" | "bot" }>`
  align-self: ${({ type }) => (type === "user" ? "flex-end" : "flex-start")};
  background: ${({ type }) => (type === "user" ? "#dcf8c6" : "#f1f0f0")};
  color: #333;
  padding: 8px 12px;
  border-radius: 16px;
  max-width: 80%;
  white-space: pre-wrap;
  line-height: 1.4;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.05);
`;

const ButtonGroup = styled.div`
  display: flex;
  flex-direction: column;
  padding: 8px;
  gap: 6px;
`;

const ChatButton = styled.button`
  padding: 8px 12px;
  background: #f9f9f9;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 13px;
  cursor: pointer;

  &:hover {
    background: #ffe082;
  }
`;
