import React, { useEffect, useState } from "react";
import styled from "@emotion/styled";

type Summary = {
  점포수: number;
  매출액: number;
  포역: number;
  계여: number;
  매출건수: number;
};

const CompareView = ({ selectedDongs }: { selectedDongs: string[] }) => {
  const [dongData, setDongData] = useState<Record<string, any[]>>({});
  const [aiResult, setAiResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/data/행정동별_상관_요약_최종.json")
      .then((res) => res.json())
      .then(setDongData);
  }, []);

  const data1 = dongData[selectedDongs[0]] || [];
  const data2 = dongData[selectedDongs[1]] || [];

  const summarize = (data: any[]): Summary => {
    return {
      점포수: data.reduce((sum, d) => sum + (d.점포수 || 0), 0),
      매출액: data.reduce((sum, d) => sum + (d.매출액 || 0), 0),
      포역: data.reduce((sum, d) => sum + (d.포역 || 0), 0),
      계여: data.reduce((sum, d) => sum + (d.계여 || 0), 0),
      매출건수: data.reduce((sum, d) => sum + (d.매출건수 || 0), 0),
    };
  };

  const s1 = summarize(data1);
  const s2 = summarize(data2);

  const summaryKeys: (keyof Summary)[] = [
    "점포수",
    "매출액",
    "포역",
    "계여",
    "매출건수",
  ];

  useEffect(() => {
    const fetchAI = async () => {
      if (selectedDongs.length !== 2) return;

      setLoading(true);
      setError(null);
      setAiResult(null);

      try {
        const response = await fetch(
          "https://asia-northeast3-where2chicken.cloudfunctions.net/compareAi",
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              name1: selectedDongs[0],
              name2: selectedDongs[1],
              summary1: s1,
              summary2: s2,
            }),
          }
        );

        const data = await response.json();

        if (data?.result) {
          setAiResult(data.result);
        } else {
          setError("AI 응답이 없습니다.");
        }
      } catch (err) {
        console.error(err);
        setError("AI 분석 요청 실패");
      } finally {
        setLoading(false);
      }
    };

    fetchAI();
  }, [selectedDongs[0], selectedDongs[1]]);

  return (
    <Wrapper>
      <h2>선택된 두 상권 비교</h2>
      {selectedDongs.length !== 2 ? (
        <p>지도에서 상권 두 개를 선택해주세요.</p>
      ) : (
        <>
          <Table>
            <thead>
              <tr>
                <th>항목</th>
                <th>{selectedDongs[0]}</th>
                <th>{selectedDongs[1]}</th>
              </tr>
            </thead>
            <tbody>
              {summaryKeys.map((key) => (
                <tr key={key}>
                  <td>{key}</td>
                  <td>{s1[key].toLocaleString()}</td>
                  <td>{s2[key].toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </Table>

          <AIBox>
            <h3>AI 분석 결과</h3>
            {loading && <p>AI가 분석 중입니다...</p>}
            {error && <p style={{ color: "red" }}>{error}</p>}
            {aiResult && <p>{aiResult}</p>}
          </AIBox>
        </>
      )}
    </Wrapper>
  );
};

export default CompareView;

const Wrapper = styled.div`
  padding: 32px;
`;

const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin-top: 24px;

  th,
  td {
    padding: 12px;
    border: 1px solid #ddd;
    text-align: center;
  }

  th {
    background: #fff3cd;
  }
`;

const AIBox = styled.div`
  background: #fffbe6;
  border: 1px solid #ffe082;
  padding: 24px;
  margin-top: 32px;
  border-radius: 12px;
`;
