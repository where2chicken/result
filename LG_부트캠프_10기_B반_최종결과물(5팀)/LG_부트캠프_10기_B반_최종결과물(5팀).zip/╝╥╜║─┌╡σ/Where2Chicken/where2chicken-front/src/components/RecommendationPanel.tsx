/** @jsxImportSource @emotion/react */
import React, { useState } from "react";
import styled from "@emotion/styled";

const RecommendationPanel = ({ data }: { data: Record<string, any[]> }) => {
  const [minSales, setMinSales] = useState(50000000);
  const [maxCompetitor, setMaxCompetitor] = useState(5);
  const [minOpenings, setMinOpenings] = useState(1);
  const [result, setResult] = useState<any[]>([]);

  const handleFilter = () => {
    const filtered = Object.entries(data)
      .flatMap(([admCd, areas]) => areas.map((d: any) => ({ ...d, admCd })))
      .filter(
        (item) =>
          item.매출액 >= minSales &&
          item.점포수 <= maxCompetitor &&
          item.개업 >= minOpenings
      )
      .sort((a, b) => b.매출액 - a.매출액)
      .slice(0, 10);

    setResult(filtered);
  };

  return (
    <Wrapper>
      <h2>조건 기반 상권 추천</h2>
      <ControlPanel>
        <div>
          최소 매출액 (₩)
          <Input
            type="number"
            value={minSales}
            onChange={(e) => setMinSales(Number(e.target.value))}
          />
        </div>
        <div>
          최대 경쟁 점포 수
          <Input
            type="number"
            value={maxCompetitor}
            onChange={(e) => setMaxCompetitor(Number(e.target.value))}
          />
        </div>
        <div>
          최소 개업 수
          <Input
            type="number"
            value={minOpenings}
            onChange={(e) => setMinOpenings(Number(e.target.value))}
          />
        </div>
        <FilterBtn onClick={handleFilter}>추천 상권 보기</FilterBtn>
      </ControlPanel>

      {result.length > 0 && (
        <ResultTable>
          <thead>
            <tr>
              <th>상권명</th>
              <th>매출액</th>
              <th>점포수</th>
              <th>개업</th>
              <th>폐업</th>
            </tr>
          </thead>
          <tbody>
            {result.map((r, i) => (
              <tr key={i}>
                <td>{r.상권명}</td>
                <td>{r.매출액.toLocaleString()}</td>
                <td>{r.점포수}</td>
                <td>{r.개업}</td>
                <td>{r.폐업}</td>
              </tr>
            ))}
          </tbody>
        </ResultTable>
      )}
    </Wrapper>
  );
};

export default RecommendationPanel;

const Wrapper = styled.div`
  padding: 32px;
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  max-width: 800px;
  margin: 0 auto;
`;

const ControlPanel = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  margin-bottom: 24px;
  align-items: flex-end;
`;

const Input = styled.input`
  display: block;
  margin-top: 4px;
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
  width: 140px;
`;

const FilterBtn = styled.button`
  padding: 10px 20px;
  background: #ffa000;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: bold;

  &:hover {
    background: #fb8c00;
  }
`;

const ResultTable = styled.table`
  width: 100%;
  border-collapse: collapse;

  th,
  td {
    padding: 10px;
    border: 1px solid #ddd;
    text-align: center;
  }

  th {
    background: #ffe082;
  }
`;
