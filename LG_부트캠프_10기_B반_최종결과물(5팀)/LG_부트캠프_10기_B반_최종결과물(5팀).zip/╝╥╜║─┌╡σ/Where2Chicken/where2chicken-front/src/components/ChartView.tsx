/** @jsxImportSource @emotion/react */
import React, { useEffect, useState } from "react";
import styled from "@emotion/styled";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";

const Container = styled.div`
  max-width: 1000px;
  margin: 0 auto;
  padding: 24px;

  @media (max-width: 768px) {
    padding: 16px;
  }
`;

const Section = styled.div`
  margin-bottom: 40px;
`;

const QuarterTabs = styled.div`
  display: flex;
  width: 100%;
  border-bottom: 2px solid #ddd;
  margin-bottom: 16px;

  @media (max-width: 768px) {
    display: none;
  }
`;

const QuarterSelect = styled.select`
  display: none;
  width: 100%;
  padding: 12px;
  font-size: 16px;
  margin-bottom: 12px;

  @media (max-width: 768px) {
    display: block;
  }
`;

const QuarterTab = styled.button<{ active: boolean }>`
  flex: 1;
  padding: 14px 0;
  font-size: 16px;
  font-weight: ${({ active }) => (active ? "bold" : "500")};
  color: ${({ active }) => (active ? "#ffa000" : "#888")};
  background: none;
  border: none;
  border-bottom: 3px solid
    ${({ active }) => (active ? "#ffa000" : "transparent")};
  cursor: pointer;

  &:hover {
    color: #ffb300;
  }
`;

const MetricTabs = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: center;
  margin-bottom: 12px;
`;

const MetricTab = styled.button<{ active: boolean }>`
  padding: 8px 14px;
  font-size: 15px;
  font-weight: 600;
  border: none;
  border-radius: 9999px;
  background: ${({ active }) => (active ? "#ffc107" : "#eeeeee")};
  color: ${({ active }) => (active ? "#333" : "#777")};
  cursor: pointer;

  &:hover {
    background: #ffe082;
  }
`;

const ChartBox = styled.div`
  background: white;
  padding: 16px;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  margin-bottom: 24px;

  h3 {
    font-size: 18px;
    margin-bottom: 12px;
    color: #333;
  }
`;

const quarters = ["1분기", "2분기", "3분기", "4분기"];
const charts = [
  {
    label: "점포수",
    fileKey: "점포수",
    unit: "개",
    isSales: false,
    isPie: false,
  },
  {
    label: "개업률",
    fileKey: "개업률",
    unit: "%",
    isSales: false,
    isPie: false,
  },
  {
    label: "폐업률",
    fileKey: "폐업률",
    unit: "%",
    isSales: false,
    isPie: false,
  },
  {
    label: "프랜차이즈수",
    fileKey: "프랜차이즈수",
    unit: "개",
    isSales: false,
    isPie: false,
  },
  {
    label: "시간대별매출",
    fileKey: "time",
    unit: "원",
    isSales: true,
    isPie: true,
  },
  {
    label: "요일별매출",
    fileKey: "yoil",
    unit: "원",
    isSales: true,
    isPie: true,
  },
];

const COLORS = [
  "#ff6f61",
  "#6a5acd",
  "#4db6ac",
  "#f06292",
  "#ba68c8",
  "#81c784",
  "#64b5f6",
  "#ffd54f",
  "#a1887f",
  "#90a4ae",
  "#e57373",
  "#9575cd",
];

const QuarterlyDashboard = () => {
  const [quarter, setQuarter] = useState("1분기");
  const [chartType, setChartType] = useState("점포수");
  const [data, setData] = useState<any[]>([]);
  const isMobile = typeof window !== "undefined" && window.innerWidth <= 768;

  const selectedChart = charts.find((c) => c.label === chartType);
  const fileKey = selectedChart?.fileKey || chartType;

  useEffect(() => {
    const fileName = `${quarter}_${fileKey}.json`;
    fetch(`/data/${fileName}`)
      .then((res) => res.json())
      .then(setData)
      .catch(() => setData([]));
  }, [quarter, chartType]);

  const isSales = selectedChart?.isSales;
  const isPie = selectedChart?.isPie;
  const unit = selectedChart?.unit || "";

  const labelKey = isPie ? Object.keys(data?.[0] || {})[0] : "상권";
  const valueKey = isPie
    ? Object.keys(data?.[0] || {})[1]
    : isSales
    ? "매출금액"
    : "값";

  const formatTick = (v: number) => {
    if (isSales) return `${(v / 1_000_000).toFixed(0)}만원`;
    if (unit === "%") return `${v.toFixed(1)}%`;
    return `${v}${unit}`;
  };

  const tooltipFormatter = (v: number) => {
    if (isSales) return `${v.toLocaleString()} 원`;
    return `${v.toLocaleString()} ${unit}`;
  };

  const formatLabelText = (name: string, percent?: number) =>
    `${String(name)
      .replace("시간대_", "")
      .replace("요일_", "")
      .replace("_매출_금액", "")
      .replace("_매출_건수", "")} (${((percent ?? 0) * 100).toFixed(1)}%)`;

  const 금액데이터 =
    chartType === "요일별매출"
      ? data.filter((d) => d[labelKey].includes("금액"))
      : [];

  const 건수데이터 =
    chartType === "요일별매출"
      ? data.filter((d) => d[labelKey].includes("건수"))
      : [];

  return (
    <Container>
      <Section>
        <QuarterTabs>
          {quarters.map((q) => (
            <QuarterTab
              key={q}
              active={quarter === q}
              onClick={() => setQuarter(q)}>
              {q}
            </QuarterTab>
          ))}
        </QuarterTabs>

        <QuarterSelect
          value={quarter}
          onChange={(e) => setQuarter(e.target.value)}>
          {quarters.map((q) => (
            <option key={q} value={q}>
              {q}
            </option>
          ))}
        </QuarterSelect>

        <MetricTabs>
          {charts.map((chart) => (
            <MetricTab
              key={chart.label}
              active={chartType === chart.label}
              onClick={() => setChartType(chart.label)}>
              {chart.label}
            </MetricTab>
          ))}
        </MetricTabs>
      </Section>

      {chartType === "요일별매출" ? (
        <>
          <ChartBox>
            <h3>요일별 매출 금액</h3>
            <ResponsiveContainer width="100%" height={isMobile ? 240 : 400}>
              <PieChart>
                <Pie
                  data={금액데이터}
                  dataKey="매출"
                  nameKey="요일"
                  outerRadius={isMobile ? 80 : 150}
                  label={
                    isMobile
                      ? false
                      : ({ name, percent }) => formatLabelText(name, percent)
                  }>
                  {금액데이터.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(v: number) => `${v.toLocaleString()} 원`}
                />
                {!isMobile && <Legend />}
              </PieChart>
            </ResponsiveContainer>
          </ChartBox>

          <ChartBox>
            <h3>요일별 매출 건수</h3>
            <ResponsiveContainer width="100%" height={isMobile ? 240 : 400}>
              <PieChart>
                <Pie
                  data={건수데이터}
                  dataKey="매출"
                  nameKey="요일"
                  outerRadius={isMobile ? 80 : 150}
                  label={
                    isMobile
                      ? false
                      : ({ name, percent }) => formatLabelText(name, percent)
                  }>
                  {건수데이터.map((_, i) => (
                    <Cell key={i} fill={COLORS[(i + 4) % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(v: number) => `${v.toLocaleString()} 건`}
                />
                {!isMobile && <Legend />}
              </PieChart>
            </ResponsiveContainer>
          </ChartBox>
        </>
      ) : chartType === "시간대별매출" ? (
        <ChartBox>
          <h3>시간대별 매출 금액 및 건수</h3>
          <ResponsiveContainer width="100%" height={isMobile ? 280 : 400}>
            <BarChart
              data={data}
              margin={{ top: 20, right: 30, left: 40, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="시간대" />
              <YAxis
                yAxisId="left"
                orientation="left"
                tickFormatter={(v) => `${(v / 1_000_000).toFixed(0)}만원`}
              />
              <YAxis
                yAxisId="right"
                orientation="right"
                tickFormatter={(v) => `${v.toLocaleString()}건`}
              />
              <Tooltip
                formatter={(value, name) =>
                  name === "매출금액"
                    ? [`${Number(value).toLocaleString()} 원`, "매출"]
                    : [`${Number(value).toLocaleString()} 건`, "건수"]
                }
              />
              <Legend />
              <Bar
                yAxisId="left"
                dataKey="매출금액"
                fill="#ffb300"
                name="매출"
                radius={[4, 4, 0, 0]}
              />
              <Bar
                yAxisId="right"
                dataKey="매출건수"
                fill="#64b5f6"
                name="건수"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </ChartBox>
      ) : (
        <ChartBox>
          <ResponsiveContainer width="100%" height={isMobile ? 280 : 400}>
            {isPie ? (
              <PieChart>
                <Pie
                  data={data}
                  dataKey={valueKey}
                  nameKey={labelKey}
                  outerRadius={isMobile ? 80 : 150}
                  label={
                    isMobile
                      ? false
                      : ({ name, percent }) => formatLabelText(name, percent)
                  }>
                  {data.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={tooltipFormatter} />
                {!isMobile && <Legend />}
              </PieChart>
            ) : (
              <BarChart
                data={data}
                layout="vertical"
                margin={{ left: 40, right: 30 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" tickFormatter={formatTick} />
                <YAxis
                  type="category"
                  dataKey={labelKey}
                  width={isMobile ? 100 : 150}
                  tick={{ fontSize: 13 }}
                />
                <Tooltip formatter={tooltipFormatter} />
                <Bar dataKey={valueKey} fill="#ffb300" radius={[4, 4, 0, 0]} />
              </BarChart>
            )}
          </ResponsiveContainer>
        </ChartBox>
      )}
    </Container>
  );
};

export default QuarterlyDashboard;
