/** @jsxImportSource @emotion/react */
import React, { useEffect, useState, useRef } from "react";
import { ComposableMap, Geographies, Geography } from "react-simple-maps";
import styled from "@emotion/styled";
import MapFilterControls, { Filters } from "./MapFilterControls";

const Tooltip = styled.div`
  position: absolute;
  background: #fffef6;
  border: 1px solid #ffc107;
  padding: 10px 12px;
  border-radius: 6px;
  pointer-events: none;
  font-size: 13px;
  line-height: 1.5;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  color: #333;
  z-index: 10;
`;

const Popover = styled.div`
  position: absolute;
  background: white;
  border: 1px solid #ccc;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  padding: 10px;
  z-index: 1000;
`;

const PopoverButton = styled.button`
  display: block;
  width: 100%;
  background: #fff8e1;
  border: 1px solid #ffe082;
  border-radius: 8px;
  padding: 8px 12px;
  margin-bottom: 6px;
  font-size: 14px;
  font-weight: bold;
  text-align: left;
  color: #333;
  cursor: pointer;

  &:hover {
    background: #ffecb3;
  }
`;

const ModalOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.3);
  z-index: 2000;
  display: flex;
  justify-content: center;
  align-items: center;
`;

const Modal = styled.div`
  background: white;
  padding: 32px;
  border-radius: 16px;
  max-width: 600px;
  width: 90%;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
`;

const CloseButton = styled.button`
  background: #f44336;
  color: white;
  border: none;
  padding: 6px 12px;
  border-radius: 6px;
  float: right;
  cursor: pointer;
`;

const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin-top: 16px;

  th,
  td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: center;
  }

  th {
    background: #fff3cd;
  }
`;

const Title = styled.h2`
  text-align: center;
  margin-top: 20px;
`;

const SubText = styled.p`
  text-align: center;
  margin: 8px 0;
  color: #666;
`;

const MapSimpleView = () => {
  const [geoData, setGeoData] = useState<any | null>(null);
  const [dongData, setDongData] = useState<Record<string, any[]>>({});
  const [hoveredDong, setHoveredDong] = useState<string | null>(null);
  const [tooltipPos, setTooltipPos] = useState<{ x: number; y: number } | null>(
    null
  );
  const [popoverInfo, setPopoverInfo] = useState<{
    x: number;
    y: number;
    admCd: string;
  } | null>(null);
  const [selectedSang, setSelectedSang] = useState<{
    admCd: string;
    상권명: string;
  } | null>(null);

  const [filters, setFilters] = useState<Filters>({
    minStores: 0,
    maxStores: 100,
    minSales: 0,
    maxSales: 1_000_000_000_000,
  });

  const mapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch("/seoul_dong.geojson")
      .then((res) => res.json())
      .then(setGeoData);
    fetch("/data/행정동별_상권_요약_최종.json")
      .then((res) => res.json())
      .then(setDongData);
  }, []);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (!(e.target as HTMLElement).closest(".popover")) {
        setPopoverInfo(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const summarize = (items: any[]): Record<string, number> => ({
    점포수: items.reduce((sum, d) => sum + (d.점포수 || 0), 0),
    매출액: items.reduce((sum, d) => sum + (d.매출액 || 0), 0),
    폐업: items.reduce((sum, d) => sum + (d.폐업 || 0), 0),
    개업: items.reduce((sum, d) => sum + (d.개업 || 0), 0),
    매출건수: items.reduce((sum, d) => sum + (d.매출건수 || 0), 0),
  });

  const isVisible = (admCd: string) => {
    const data = dongData[admCd];
    if (!data || data.length === 0) return false;

    const total = summarize(data);
    return (
      total.점포수 >= filters.minStores &&
      total.점포수 <= filters.maxStores &&
      total.매출액 >= filters.minSales &&
      total.매출액 <= filters.maxSales
    );
  };

  const getFillColor = (admCd: string) => {
    const data = dongData[admCd];
    if (!data || data.length === 0) return "#f0f0f0";
    const total = data.reduce((sum, d) => sum + (d.점포수 || 0), 0);
    return total > 50
      ? "#b2182b"
      : total > 30
      ? "#ef8a62"
      : total > 10
      ? "#fddbc7"
      : "#d1e5f0";
  };

  return (
    <div
      ref={mapRef}
      style={{ position: "relative", maxWidth: 900, margin: "0 auto" }}>
      <Title>서울시 상권 지도</Title>
      <SubText>조건에 맞는 상권을 클릭해 상세 정보를 확인해보세요.</SubText>
      <MapFilterControls onFilterChange={(f) => setFilters(f)} />{" "}
      {/* ✅ 필터 UI 적용 */}
      {geoData && (
        <ComposableMap
          projection="geoMercator"
          projectionConfig={{ scale: 90000, center: [126.99, 37.56] }}
          width={800}
          height={600}>
          <Geographies geography={geoData}>
            {({ geographies }) =>
              geographies.map((geo) => {
                const admCd = geo.properties.adm_cd2;
                const visible = isVisible(admCd);

                return (
                  <Geography
                    key={geo.rsmKey}
                    geography={geo}
                    onMouseEnter={(e) => {
                      if (!visible) return;
                      const rect = mapRef.current?.getBoundingClientRect();
                      if (rect) {
                        setHoveredDong(admCd);
                        setTooltipPos({
                          x: e.clientX - rect.left + 10,
                          y: e.clientY - rect.top + 10,
                        });
                      }
                    }}
                    onMouseLeave={() => {
                      setHoveredDong(null);
                      setTooltipPos(null);
                    }}
                    onClick={(e) => {
                      if (!visible) return;
                      const rect = mapRef.current?.getBoundingClientRect();
                      if (rect) {
                        setPopoverInfo({
                          x: e.clientX - rect.left + 10,
                          y: e.clientY - rect.top + 10,
                          admCd,
                        });
                      }
                    }}
                    style={{
                      default: {
                        fill: visible ? getFillColor(admCd) : "#ffffff",
                        stroke: "#CCC",
                        strokeWidth: 0.5,
                        cursor: visible ? "pointer" : "default",
                      },
                      hover: {
                        fill: visible ? "#ffb74d" : "#ffffff",
                        stroke: "#999",
                        strokeWidth: 0.8,
                      },
                      pressed: {
                        fill: visible ? "#ef6c00" : "#ffffff",
                      },
                    }}
                  />
                );
              })
            }
          </Geographies>
        </ComposableMap>
      )}
      {hoveredDong && tooltipPos && dongData[hoveredDong] && (
        <Tooltip style={{ top: tooltipPos.y, left: tooltipPos.x }}>
          <strong>
            {
              geoData?.features.find(
                (f: any) => f.properties.adm_cd2 === hoveredDong
              )?.properties.adm_nm
            }
          </strong>
          <div style={{ marginTop: 6 }}>
            {dongData[hoveredDong].map((sg, idx) => (
              <div key={idx} style={{ marginTop: 6 }}>
                <div>
                  <strong>{sg.상권명}</strong>
                </div>
                <div>점포수: {sg.점포수}</div>
                <div>매출액: {sg.매출액.toLocaleString()}원</div>
              </div>
            ))}
          </div>
        </Tooltip>
      )}
      {popoverInfo && dongData[popoverInfo.admCd] && (
        <Popover
          className="popover"
          style={{ top: popoverInfo.y, left: popoverInfo.x }}>
          <p>
            <strong>상권 선택</strong>
          </p>
          {dongData[popoverInfo.admCd].map((sg, i) => (
            <PopoverButton
              key={i}
              onClick={() => {
                setSelectedSang({
                  admCd: popoverInfo.admCd,
                  상권명: sg.상권명,
                });
                setPopoverInfo(null);
              }}>
              {sg.상권명}
            </PopoverButton>
          ))}
        </Popover>
      )}
      {selectedSang && (
        <ModalOverlay onClick={() => setSelectedSang(null)}>
          <Modal onClick={(e) => e.stopPropagation()}>
            <CloseButton onClick={() => setSelectedSang(null)}>
              닫기
            </CloseButton>
            <h3>상권 상세 정보</h3>
            <p>
              <strong>상권명:</strong> {selectedSang.상권명}
            </p>
            <Table>
              <thead>
                <tr>
                  <th>항목</th>
                  <th>값</th>
                </tr>
              </thead>
              <tbody>
                {(() => {
                  const matched = dongData[selectedSang.admCd]?.find(
                    (d) => d.상권명 === selectedSang.상권명
                  );
                  if (!matched) return null;
                  const summary = summarize([matched]);
                  return Object.entries(summary).map(([key, val]) => (
                    <tr key={key}>
                      <td>{key}</td>
                      <td>{val.toLocaleString()}</td>
                    </tr>
                  ));
                })()}
              </tbody>
            </Table>
          </Modal>
        </ModalOverlay>
      )}
    </div>
  );
};

export default MapSimpleView;
