/** @jsxImportSource @emotion/react */
import React, { useEffect, useState, useRef } from "react";
import { ComposableMap, Geographies, Geography } from "react-simple-maps";
import styled from "@emotion/styled";
import MapFilterControls, { Filters } from "./MapFilterControls";

const Tooltip = styled.div`
  position: absolute;
  background: #fffef6;
  border: 1px solid #ffc107;
  padding: 10px 12px;
  border-radius: 6px;
  pointer-events: none;
  font-size: 13px;
  line-height: 1.5;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  color: #333;
  z-index: 10;
`;

const PopoverButton = styled.button`
  display: block;
  width: 100%;
  background: #fff8e1;
  border: 1px solid #ffe082;
  border-radius: 8px;
  padding: 8px 12px;
  margin-bottom: 6px;
  font-size: 14px;
  font-weight: bold;
  text-align: left;
  color: #333;
  cursor: pointer;
  transition: background 0.2s;

  &:hover {
    background: #ffecb3;
  }
`;

const SelectionWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 24px auto;
  max-width: 700px;
  padding: 12px 24px;
  border: 1px solid #ddd;
  border-radius: 12px;
  background: #fafafa;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
`;

const SelectionBox = styled.div`
  display: flex;
  align-items: center;
  gap: 12px;
`;

const SelectedItem = styled.div`
  padding: 10px 18px;
  background: #fff8e1;
  border-radius: 12px;
  border: 1px solid #ffe082;
  font-weight: bold;
  color: #333;
  display: flex;
  align-items: center;
  gap: 8px;
`;

const RemoveBtn = styled.button`
  background: none;
  border: none;
  color: #f44336;
  font-size: 16px;
  cursor: pointer;
  margin-left: 4px;
  &:hover {
    color: #d32f2f;
  }
`;

const CompareButton = styled.button<{ disabled?: boolean }>`
  background: ${({ disabled }) => (disabled ? "#ccc" : "#ff9800")};
  color: white;
  border: none;
  padding: 10px 16px;
  border-radius: 8px;
  font-weight: bold;
  cursor: ${({ disabled }) => (disabled ? "not-allowed" : "pointer")};
  box-shadow: ${({ disabled }) =>
    disabled ? "none" : "0 4px 12px rgba(0, 0, 0, 0.2)"};
  transition: background 0.3s;

  &:hover {
    background: ${({ disabled }) => (disabled ? "#ccc" : "#fb8c00")};
  }
`;

const Popover = styled.div`
  position: absolute;
  background: white;
  border: 1px solid #ccc;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  padding: 10px;
  z-index: 1000;
`;

const ModalOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.3);
  z-index: 2000;
  display: flex;
  justify-content: center;
  align-items: center;
`;

const Modal = styled.div`
  background: white;
  width: 90%;
  max-width: 600px;
  max-height: 70vh;
  overflow-y: auto;
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 6px 24px rgba(0, 0, 0, 0.15);

  @media (max-width: 768px) {
    max-height: 90vh;
    padding: 20px;
  }
`;

const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin-top: 16px;

  th,
  td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: center;
  }

  th {
    background: #fff3cd;
  }
`;

const AnalyzeButton = styled.button`
  position: fixed;
  bottom: 100px;
  left: 24px;
  background: #ffb300;
  color: white;
  border: none;
  border-radius: 20px;
  padding: 12px 20px;
  font-size: 16px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  cursor: pointer;
  z-index: 1000;
`;

const CloseButton = styled.button`
  background: #f44336;
  color: white;
  border: none;
  padding: 6px 12px;
  border-radius: 6px;
  float: right;
  cursor: pointer;
`;

const Title = styled.h2`
  text-align: center;
  margin-top: 20px;
`;

const SubText = styled.p`
  text-align: center;
  margin: 8px 0;
  color: #666;
`;

const SelectedList = styled.ul`
  text-align: center;
  list-style: none;
  padding: 0;
  margin-bottom: 20px;
  color: #444;
  font-size: 14px;
`;

const MapView = () => {
  const [geoData, setGeoData] = useState<any | null>(null);
  const [dongData, setDongData] = useState<Record<string, any[]>>({});
  const [hoveredDong, setHoveredDong] = useState<string | null>(null);
  const [tooltipPos, setTooltipPos] = useState<{ x: number; y: number } | null>(
    null
  );
  const [popoverInfo, setPopoverInfo] = useState<{
    x: number;
    y: number;
    admCd: string;
  } | null>(null);
  const [showModal, setShowModal] = useState(false);

  const [filters, setFilters] = useState<Filters>({
    minStores: 0,
    maxStores: 100,
    minSales: 0,
    maxSales: 1000000000000,
  });

  const [selectedDongs, setSelectedDongs] = useState<
    ({ admCd: string; 상권명: string } | null)[]
  >([null, null]);

  const isVisible = (admCd: string) => {
    const data = dongData[admCd];
    if (!data || data.length === 0) return false;

    const total = summarize(data);
    return (
      total.점포수 >= filters.minStores &&
      total.점포수 <= filters.maxStores &&
      total.매출액 >= filters.minSales &&
      total.매출액 <= filters.maxSales
    );
  };

  const mapRef = useRef<HTMLDivElement>(null);
  const popoverRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch("/seoul_dong.geojson")
      .then((res) => res.json())
      .then(setGeoData);
    fetch("/data/행정동별_상권_요약_최종.json")
      .then((res) => res.json())
      .then(setDongData);
  }, []);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (
        popoverRef.current &&
        !popoverRef.current.contains(e.target as Node)
      ) {
        setPopoverInfo(null);
      }
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const handleSelect = (admCd: string, 상권명: string) => {
    setSelectedDongs((prev) => {
      const updated = [...prev];
      const newItem = { admCd, 상권명 };

      const emptyIndex = updated.findIndex((slot) => slot === null);
      if (emptyIndex !== -1) {
        updated[emptyIndex] = newItem;
      }

      return updated;
    });

    setPopoverInfo(null);
  };

  const summarize = (items: any[]): Record<string, number> => {
    const result: Record<string, number> = {};

    items.forEach((item) => {
      for (const key in item) {
        const value = item[key];

        if (typeof value === "number") {
          result[key] = (result[key] || 0) + value;
        }
      }
    });

    return result;
  };

  const getFillColor = (admCd: string) => {
    const data = dongData[admCd];
    if (!data || data.length === 0) return "#f0f0f0";
    const total = data.reduce((sum, d) => sum + (d.점포수 || 0), 0);
    return total > 50
      ? "#b2182b"
      : total > 30
      ? "#ef8a62"
      : total > 10
      ? "#fddbc7"
      : "#d1e5f0";
  };

  return (
    <div
      ref={mapRef}
      style={{ position: "relative", maxWidth: 900, margin: "0 auto" }}>
      {/* <Title>서울시 상권별 치킨집 분포</Title> */}
      <SubText>두 개의 상권을 선택하면 비교할 수 있습니다.</SubText>
      <SelectionWrapper>
        <SelectionBox>
          <SelectedItem>
            {selectedDongs[0]?.상권명 || "상권 1"}
            {selectedDongs[0] && (
              <RemoveBtn
                onClick={() =>
                  setSelectedDongs((prev) => {
                    const updated = [...prev];
                    updated[0] = null;
                    return updated;
                  })
                }>
                ✕
              </RemoveBtn>
            )}
          </SelectedItem>

          <span>:</span>

          <SelectedItem>
            {selectedDongs[1]?.상권명 || "상권 2"}
            {selectedDongs[1] && (
              <RemoveBtn
                onClick={() =>
                  setSelectedDongs((prev) => {
                    const updated = [...prev];
                    updated[1] = null;
                    return updated;
                  })
                }>
                ✕
              </RemoveBtn>
            )}
          </SelectedItem>
        </SelectionBox>

        <CompareButton
          disabled={!selectedDongs[0] || !selectedDongs[1]}
          onClick={() => setShowModal(true)}>
          비교 분석하기
        </CompareButton>
      </SelectionWrapper>
      {geoData && (
        <ComposableMap
          projection="geoMercator"
          projectionConfig={{ scale: 90000, center: [126.99, 37.56] }}
          width={800}
          height={600}>
          <Geographies geography={geoData}>
            {({ geographies }) =>
              geographies.map((geo) => {
                const admCd = geo.properties.adm_cd2;
                const visible = isVisible(admCd);

                return (
                  <Geography
                    key={geo.rsmKey}
                    geography={geo}
                    onMouseEnter={(e) => {
                      if (!visible) return;
                      const rect = mapRef.current?.getBoundingClientRect();
                      if (rect) {
                        setHoveredDong(admCd);
                        setTooltipPos({
                          x: e.clientX - rect.left + 10,
                          y: e.clientY - rect.top + 10,
                        });
                      }
                    }}
                    onMouseLeave={() => {
                      if (!visible) return;
                      setHoveredDong(null);
                      setTooltipPos(null);
                    }}
                    onClick={(e) => {
                      if (!visible) return;
                      const rect = mapRef.current?.getBoundingClientRect();
                      if (rect) {
                        setPopoverInfo({
                          x: e.clientX - rect.left + 10,
                          y: e.clientY - rect.top + 10,
                          admCd,
                        });
                      }
                    }}
                    style={{
                      default: {
                        fill: visible ? getFillColor(admCd) : "#ffffff",
                        stroke: "#CCC", // 테두리는 항상 표시
                        strokeWidth: 0.5,
                        cursor: visible ? "pointer" : "default",
                      },
                      hover: {
                        fill: visible ? "#ffb74d" : "#ffffff",
                        stroke: "#999",
                        strokeWidth: 0.8,
                      },
                      pressed: {
                        fill: visible ? "#ef6c00" : "#ffffff",
                      },
                    }}
                  />
                );
              })
            }
          </Geographies>
        </ComposableMap>
      )}

      {hoveredDong && tooltipPos && dongData[hoveredDong] && (
        <Tooltip style={{ top: tooltipPos.y, left: tooltipPos.x }}>
          <strong>
            {
              geoData?.features.find(
                (f: any) => f.properties.adm_cd2 === hoveredDong
              )?.properties.adm_nm
            }
          </strong>
          <div style={{ marginTop: 6 }}>
            {dongData[hoveredDong].map((sg, idx) => (
              <div key={idx} style={{ marginTop: 6 }}>
                <div>
                  <strong>{sg.상권명}</strong>
                </div>
                <div>점포수: {sg.점포수}</div>
                <div>
                  개업: {sg.개업}, 폐업: {sg.폐업}
                </div>
                <div>매출액: {sg.매출액.toLocaleString()}원</div>
                <div>매출건수: {sg.매출건수.toLocaleString()}건</div>
              </div>
            ))}
          </div>
        </Tooltip>
      )}

      {popoverInfo && dongData[popoverInfo.admCd] && (
        <Popover
          ref={popoverRef}
          style={{ top: popoverInfo.y, left: popoverInfo.x }}>
          <p>
            <strong>상권 선택</strong>
          </p>
          {dongData[popoverInfo.admCd].map((sg, i) => (
            <PopoverButton
              key={i}
              onClick={() => handleSelect(popoverInfo.admCd, sg.상권명)}>
              {sg.상권명}
            </PopoverButton>
          ))}
        </Popover>
      )}

      {showModal && selectedDongs[0] && selectedDongs[1] && (
        <ModalOverlay onClick={() => setShowModal(false)}>
          <Modal onClick={(e) => e.stopPropagation()}>
            <CloseButton
              onClick={() => {
                setShowModal(false);
                setSelectedDongs([null, null]);
              }}>
              닫기
            </CloseButton>

            <h3>선택된 두 상권 비교</h3>

            <Table>
              <thead>
                <tr>
                  <th>항목</th>
                  <th>{selectedDongs[0]!.상권명}</th>
                  <th>{selectedDongs[1]!.상권명}</th>
                </tr>
              </thead>
              <tbody>
                {["점포수", "매출액", "폐업", "개업", "매출건수"].map((key) => {
                  const d1 = summarize(
                    (dongData[selectedDongs[0]!.admCd] || []).filter(
                      (d) => d.상권명 === selectedDongs[0]!.상권명
                    )
                  );
                  const d2 = summarize(
                    (dongData[selectedDongs[1]!.admCd] || []).filter(
                      (d) => d.상권명 === selectedDongs[1]!.상권명
                    )
                  );

                  return (
                    <tr key={key}>
                      <td>{key}</td>
                      <td>{d1[key].toLocaleString()}</td>
                      <td>{d2[key].toLocaleString()}</td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>

            <AIRecommendation
              name1={selectedDongs[0]!.상권명}
              name2={selectedDongs[1]!.상권명}
              summary1={summarize(
                (dongData[selectedDongs[0]!.admCd] || []).filter(
                  (d) => d.상권명 === selectedDongs[0]!.상권명
                )
              )}
              summary2={summarize(
                (dongData[selectedDongs[1]!.admCd] || []).filter(
                  (d) => d.상권명 === selectedDongs[1]!.상권명
                )
              )}
            />
          </Modal>
        </ModalOverlay>
      )}
    </div>
  );
};

const AIRecommendation = ({
  name1,
  name2,
  summary1,
  summary2,
}: {
  name1: string;
  name2: string;
  summary1: any;
  summary2: any;
}) => {
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAI = async () => {
      setLoading(true);
      setError(null);
      setResult(null);

      try {
        const res = await fetch(
          "https://asia-northeast3-where2chicken.cloudfunctions.net/compareAi",
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name1, name2, summary1, summary2 }),
          }
        );
        console.log(summary1);
        const json = await res.json();
        if (json.result) setResult(json.result);
        else setError("AI 응답 오류");
      } catch (e) {
        setError("AI 요청 실패");
      } finally {
        setLoading(false);
      }
    };

    fetchAI();
  }, [name1, name2]);

  return (
    <AIBox>
      <h4>AI 분석 결과</h4>
      {loading && <p>분석 중입니다...</p>}
      {error && <p style={{ color: "red" }}>{error}</p>}
      {result &&
        result
          .split("\n")
          .filter((line) => line.trim() !== "")
          .map((line, idx) => {
            const [label, ...rest] = line.split(":");
            const content = rest.join(":").trim();

            let emoji = "";
            switch (label.trim()) {
              case "- 추천 상권":
                emoji = "✅";
                break;
              case "- 추천 이유":
                emoji = "📌";
                break;
              case "- 세부 분석":
                emoji = "🔍";
                break;
              case "- 기타 참고사항":
                emoji = "💬";
                break;
              default:
                emoji = "•";
            }

            return (
              <p key={idx}>
                <strong style={{ display: "inline-block", minWidth: "110px" }}>
                  {emoji} {label.replace("-", "").trim()}:
                </strong>{" "}
                {content}
              </p>
            );
          })}
    </AIBox>
  );
};

const AIBox = styled.div`
  background: #fffde7;
  border: 1px solid #ffe082;
  margin-top: 24px;
  padding: 16px;
  border-radius: 12px;
`;

export default MapView;
