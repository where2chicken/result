/** @jsxImportSource @emotion/react */
import React, { useState, useEffect } from "react";
import styled from "@emotion/styled";
import MapView from "./components/MapView";
import ChartView from "./components/ChartView";
import TableView from "./components/TableView";
import ChatAssistant from "./components/ChatAssistant";
import RecommendationPanel from "./components/RecommendationPanel";
import MapSimpleView from "./components/MapSimpleView";
import { motion } from "framer-motion";
import bgImage from "./asset/bg.png";

const App = () => {
  const [isIntroVisible, setIsIntroVisible] = useState(true);
  const [activeTab, setActiveTab] = useState<
    "map" | "table" | "chart" | "recommend"
  >("map");
  const [dongData, setDongData] = useState<Record<string, any[]>>({});
  const isMobile = typeof window !== "undefined" && window.innerWidth <= 768;

  useEffect(() => {
    fetch("/data/행정동별_상권_요약_최종.json")
      .then((res) => res.json())
      .then((data) => setDongData(data));
  }, []);

  if (isIntroVisible) {
    return (
      <IntroContainer>
        <motion.img
          src={bgImage}
          alt="치킨"
          initial={{ y: -100, opacity: 0, rotate: -30 }}
          animate={{ y: 0, opacity: 1, rotate: 0 }}
          transition={{ duration: 1 }}
          className="chicken"
        />
        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="title">
          WHERE CHICKEN
        </motion.h1>
        <StartButton onClick={() => setIsIntroVisible(false)}>
          시작하기 🍗
        </StartButton>
      </IntroContainer>
    );
  }

  return (
    <PageWrapper>
      {!isMobile && (
        <TopNav>
          <LeftLogo>🍗 치킨집 창업 위치 찾기</LeftLogo>
          <TabMenu>
            <TabItem
              active={activeTab === "map"}
              onClick={() => setActiveTab("map")}>
              지도
            </TabItem>
            <TabItem
              active={activeTab === "recommend"}
              onClick={() => setActiveTab("recommend")}>
              비교
            </TabItem>
            <TabItem
              active={activeTab === "chart"}
              onClick={() => setActiveTab("chart")}>
              그래프
            </TabItem>
          </TabMenu>
        </TopNav>
      )}

      <ContentWrapper>
        {activeTab === "map" && <MapSimpleView />}
        {activeTab === "chart" && <ChartView />}
        {activeTab === "recommend" && <MapView />}
      </ContentWrapper>

      <ChatAssistant />

      {isMobile && (
        <>
          <BottomTabNav>
            <TabIconItem
              active={activeTab === "map"}
              onClick={() => setActiveTab("map")}>
              🗺️
              <div>지도</div>
            </TabIconItem>
            <TabIconItem
              active={activeTab === "chart"}
              onClick={() => setActiveTab("chart")}>
              📊
              <div>그래프</div>
            </TabIconItem>
            <TabIconItem
              active={activeTab === "recommend"}
              onClick={() => setActiveTab("recommend")}>
              🌟
              <div>추천</div>
            </TabIconItem>
          </BottomTabNav>
        </>
      )}
    </PageWrapper>
  );
};

export default App;

const PageWrapper = styled.div`
  background: #fffbea;
  min-height: 100vh;
  font-family: "Noto Sans KR", sans-serif;
`;

const TopNav = styled.header`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 16px 40px;
  background: #ffffff;
  border-bottom: 4px solid #ffd43b;
`;

const LeftLogo = styled.div`
  position: absolute;
  left: 40px;
  font-size: 22px;
  font-weight: 800;
  color: #333;
`;

const TabMenu = styled.nav`
  display: flex;
  gap: 28px;
`;

const TabItem = styled.div<{ active: boolean }>`
  font-size: 16px;
  cursor: pointer;
  font-weight: ${({ active }) => (active ? "700" : "400")};
  color: ${({ active }) => (active ? "#ff9900" : "#888")};
  border-bottom: ${({ active }) => (active ? "3px solid #ffb300" : "none")};
  padding-bottom: 4px;

  &:hover {
    color: #ffb300;
  }
`;

const ContentWrapper = styled.main`
  max-width: 960px;
  margin: 40px auto;
  background: white;
  padding: 40px;
  border-radius: 16px;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.05);

  @media (max-width: 768px) {
    margin: 20px 16px 100px;
    padding: 24px;
    border-radius: 12px;
  }
`;

const BottomTabNav = styled.nav`
  position: fixed;
  bottom: 0;
  width: 100%;
  background: white;
  border-top: 1px solid #ddd;
  display: flex;
  justify-content: space-around;
  padding: 10px 0;
  z-index: 100;
`;

const TabIconItem = styled.div<{ active: boolean }>`
  font-size: 14px;
  color: ${({ active }) => (active ? "#ff9900" : "#999")};
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;

  div {
    font-size: 12px;
    margin-top: 4px;
  }
`;

const IntroContainer = styled.div`
  background: #fff6de;
  height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  overflow: hidden;

  .chicken {
    width: 800px;
    margin-bottom: 32px;

    @media (max-width: 768px) {
      width: 260px;
    }
  }

  .title {
    font-family: "Caveat", "Nanum Pen Script", cursive;
    font-size: 3.5rem;
    font-weight: 800;
    color: #ff9800;
    margin-bottom: 32px;

    @media (max-width: 768px) {
      font-size: 2.3rem;
    }
  }
`;

const StartButton = styled.button`
  background: #ffb300;
  color: white;
  font-size: 18px;
  font-weight: 700;
  padding: 14px 28px;
  border: none;
  border-radius: 999px;
  cursor: pointer;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);

  &:hover {
    background: #ffa000;
  }
`;
